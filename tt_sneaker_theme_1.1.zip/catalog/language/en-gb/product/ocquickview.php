<?php
$_['text_close'] = "Close";