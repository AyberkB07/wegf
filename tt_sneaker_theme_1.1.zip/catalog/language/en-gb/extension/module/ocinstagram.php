<?php
// Heading
$_['heading_title2']    = '<span>#Wenro</span>.Lookbook';
$_['heading_title']    = 'Instagram';

$_['text_follow']        = 'Follow us on Instagram';
$_['text_des']        = 'View Our 2016 Lookbook Feed';
$_['text_copyright']        = 'Instagram -- &copy; %s';
$_['text_error']        = 'Server not found';