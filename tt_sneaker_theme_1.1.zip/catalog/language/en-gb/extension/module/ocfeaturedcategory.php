<?php
// Heading
$_['heading_title'] = 'Featured Categories';
$_['view_more'] = 'view more';